"""Split Screen: mehrere Bild-in-Bild-Blöcke teilen sich das Bild in Felder (je Block ein Feld, das Bild füllt das Feld aus).

Ein Block mit `cell = [x, y, Breite, Höhe]` (in % des Bildes) wird im Export nicht als kleines Bild eingeblendet, sondern
auf dieses Feld zugeschnitten und exakt dort platziert. Die Felder eines Layouts schließen lückenlos aneinander an.
"""
from __future__ import annotations

from .project import Project

MIN_OVERLAP = 0.05          # so lange (s) müssen Blöcke gleichzeitig laufen

# (Kennung, Name, Felder [x, y, Breite, Höhe] in %)
LAYOUTS: list[tuple[str, str, list[list[float]]]] = [
    ("2h", "2 nebeneinander", [[0, 0, 50, 100], [50, 0, 50, 100]]),
    ("2v", "2 übereinander", [[0, 0, 100, 50], [0, 50, 100, 50]]),
    ("3l", "1 groß + 2 klein", [[0, 0, 50, 100], [50, 0, 50, 50], [50, 50, 50, 50]]),
    ("3c", "3 nebeneinander", [[0, 0, 100 / 3, 100], [100 / 3, 0, 100 / 3, 100], [200 / 3, 0, 100 / 3, 100]]),
    ("4", "4er-Raster", [[0, 0, 50, 50], [50, 0, 50, 50], [0, 50, 50, 50], [50, 50, 50, 50]]),
]


class SplitError(Exception):
    pass


def layout(layout_id: str):
    for lid, name, cells in LAYOUTS:
        if lid == layout_id:
            return name, [list(c) for c in cells]
    raise SplitError(f"Unbekanntes Layout: {layout_id}")


def valid_cell(cell) -> tuple[float, float, float, float] | None:
    """Gültiges Feld als (x, y, w, h) – sonst None (kaputte Werte werden ignoriert)."""
    try:
        x, y, w, h = (float(v) for v in cell)
    except (TypeError, ValueError):
        return None
    if not all(v == v for v in (x, y, w, h)) or w < 1.0 or h < 1.0 or x < 0 or y < 0 or x + w > 100.5 or y + h > 100.5:
        return None
    return x, y, w, h


def cell_px(o, width: int, height: int) -> tuple[int, int, int, int] | None:
    """Feld des Blocks in Bildpunkten (x, y, Breite, Höhe); benachbarte Felder lassen weder Lücke noch Überlappung."""
    c = valid_cell(getattr(o, "cell", None))
    if c is None:
        return None
    x, y, w, h = c
    x0, x1 = round(width * x / 100.0), round(width * (x + w) / 100.0)
    y0, y1 = round(height * y / 100.0), round(height * (y + h) / 100.0)
    x1, y1 = min(x1, width), min(y1, height)
    if x1 - x0 < 2 or y1 - y0 < 2:
        return None
    return x0, y0, x1 - x0, y1 - y0


def is_split(o) -> bool:
    return valid_cell(getattr(o, "cell", None)) is not None


def candidates(project: Project, sel: int = -1, t: float = 0.0) -> list[int]:
    """Blöcke, die zusammen in ein Split passen: gleichzeitig zum gewählten Block (oder zur Zeit t). Gewählter zuerst."""
    ovs = project.overlays
    if 0 <= sel < len(ovs):
        a0, a1 = ovs[sel].start, ovs[sel].start + ovs[sel].length
        rest = [i for i, o in enumerate(ovs) if i != sel and min(a1, o.start + o.length) - max(a0, o.start) > MIN_OVERLAP]
        return [sel] + rest
    return [i for i, o in enumerate(ovs) if o.start <= t < o.start + o.length]


def apply(project: Project, layout_id: str, sel: int = -1, t: float = 0.0, indices=None) -> list[int]:
    """Weist den ersten Blöcken (siehe `candidates`, oder die ausdrücklich genannten `indices`) je ein Feld zu."""
    name, cells = layout(layout_id)
    cand = [i for i in indices if 0 <= i < len(project.overlays)] if indices is not None else candidates(project, sel, t)
    if len(cand) < len(cells):
        raise SplitError(f"„{name}“ braucht {len(cells)} Bild-in-Bild-Blöcke zur selben Zeit – gefunden: {len(cand)}.")
    used = cand[:len(cells)]
    for i, c in zip(used, cells):
        o = project.overlays[i]
        o.cell = [round(v, 4) for v in c]
        o.border = False
    return used


def clear(project: Project, indices=None) -> int:
    """Hebt das Split auf (alle oder die genannten Blöcke); gibt die Anzahl geänderter Blöcke zurück."""
    n = 0
    for i, o in enumerate(project.overlays):
        if (indices is None or i in indices) and o.cell:
            o.cell = []
            n += 1
    return n
